(function($) {
  $(document).ready(function(){
    // Target your .container, .wrapper, .post, etc.
    $("#page").fitVids();
  });
  
  })(jQuery);