<?php
// 404 Page
get_header(); ?>

<div id="primary" class="container content-area">
	<main id="main" class="sixteen columns site-main" role="main">
		<h1>Page not found.</h1>
		<p>Try Searching what you are looking for!<br/><?php get_search_form(); ?></p>
	</main>

</div><!-- #primary -->

<?php get_footer(); ?>