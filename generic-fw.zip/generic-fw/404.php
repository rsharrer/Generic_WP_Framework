<?php get_header(); ?>

	<div id="main" class="container">
		<div id="content" class="sixteen columns">
			<h1>Page not found.</h1>
		</div>
	</div>

<?php get_footer(); ?>