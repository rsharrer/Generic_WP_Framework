  $(document).ready(function(){
    // Target your .container, .wrapper, .post, etc.
    $("#main").fitVids();
  });

    $(window).ready(function () {
		$('#primary_nav').ReSmenu({ maxWidth: 767 });
    });