(function($) {
  $(document).ready(function(){
    // Target your .container, .wrapper, .post, etc.
    $("#main").fitVids();
  });
  
  })(jQuery);